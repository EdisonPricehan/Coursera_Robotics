%% Script to test student's implementation of Module 2
disp('Evaluating...');
evaluate();
